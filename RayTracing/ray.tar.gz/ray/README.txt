Parter name: Alyssa Eldridge
eid: AJE2273
cs login: eldrialy

Partner name: Rohil Verma
eid: rbv299
cs login rohil